import React from 'react';
import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Badge,
  Box,
  Text,
  Tooltip,
  Icon,
} from '@chakra-ui/react';
import { FiAlertCircle, FiClock } from 'react-icons/fi';
import { PuantajDetay } from '../types/puantaj.types';
import {
  formatTarih,
  formatSaat24,
  formatTimeSpan,
  formatDakika,
  getGunDurumuBadgeClass,
  getGunDurumuText,
} from '../utils/puantajUtils';

interface GunlukDetayTablosuProps {
  detaylar: PuantajDetay[];
  showVardiya?: boolean;
}

const GunlukDetayTablosu: React.FC<GunlukDetayTablosuProps> = ({
  detaylar,
  showVardiya = true,
}) => {
  const getBadgeColorScheme = (durum: string): string => {
    const classMap: { [key: string]: string } = {
      success: 'green',
      info: 'blue',
      warning: 'yellow',
      danger: 'red',
      secondary: 'gray',
      primary: 'purple',
    };
    return classMap[getGunDurumuBadgeClass(durum)] || 'gray';
  };

  return (
    <Box overflowX="auto" borderWidth="1px" borderRadius="lg">
      <Table variant="simple" size="sm">
        <Thead bg="gray.50">
          <Tr>
            <Th>Tarih</Th>
            <Th>Gün</Th>
            {showVardiya && <Th>Vardiya</Th>}
            <Th>Planlanan</Th>
            <Th>Gerçekleşen</Th>
            <Th textAlign="center">Çalışma</Th>
            <Th textAlign="center">Fazla Mesai</Th>
            <Th textAlign="center">Durum</Th>
            <Th>Notlar</Th>
          </Tr>
        </Thead>
        <Tbody>
          {detaylar.map((detay) => (
            <Tr
              key={detay.id}
              bg={
                detay.haftaSonuMu
                  ? 'gray.50'
                  : detay.resmiTatilMi
                  ? 'blue.50'
                  : detay.devamsizMi
                  ? 'red.50'
                  : 'white'
              }
            >
              <Td fontWeight="medium">
                {formatTarih(detay.tarih)}
              </Td>
              
              <Td>
                <Text fontSize="sm">{detay.gun}</Text>
              </Td>

              {showVardiya && (
                <Td>
                  <Text fontSize="sm">{detay.vardiyaAdi || '-'}</Text>
                </Td>
              )}

              <Td>
                {detay.planlananGiris && detay.planlananCikis ? (
                  <Box>
                    <Text fontSize="sm">
                      {formatTimeSpan(detay.planlananGiris)} -{' '}
                      {formatTimeSpan(detay.planlananCikis)}
                    </Text>
                  </Box>
                ) : (
                  <Text fontSize="sm" color="gray.400">
                    -
                  </Text>
                )}
              </Td>

              <Td>
                {detay.gerceklesenGiris && detay.gerceklesenCikis ? (
                  <Box>
                    <Text fontSize="sm">
                      {formatSaat24(detay.gerceklesenGiris)} -{' '}
                      {formatSaat24(detay.gerceklesenCikis)}
                    </Text>
                    {(detay.gecKaldiMi || detay.erkenCiktiMi) && (
                      <Box mt={1}>
                        {detay.gecKaldiMi && (
                          <Tooltip label={`${detay.gecKalmaSuresi} dakika geç`}>
                            <Badge colorScheme="red" fontSize="xs" mr={1}>
                              <Icon as={FiAlertCircle} mr={1} />
                              Geç
                            </Badge>
                          </Tooltip>
                        )}
                        {detay.erkenCiktiMi && (
                          <Tooltip label={`${detay.erkenCikisSuresi} dakika erken`}>
                            <Badge colorScheme="orange" fontSize="xs">
                              <Icon as={FiClock} mr={1} />
                              Erken
                            </Badge>
                          </Tooltip>
                        )}
                      </Box>
                    )}
                  </Box>
                ) : (
                  <Text fontSize="sm" color="gray.400">
                    -
                  </Text>
                )}
              </Td>

              <Td textAlign="center">
                <Text fontSize="sm" fontWeight="medium">
                  {detay.gerceklesenSure
                    ? formatDakika(detay.gerceklesenSure)
                    : '-'}
                </Text>
                {detay.normalMesai && (
                  <Text fontSize="xs" color="gray.500">
                    Normal: {formatDakika(detay.normalMesai)}
                  </Text>
                )}
              </Td>

              <Td textAlign="center">
                {detay.fazlaMesai && detay.fazlaMesai > 0 ? (
                  <Badge colorScheme="green">
                    {formatDakika(detay.fazlaMesai)}
                  </Badge>
                ) : (
                  <Text fontSize="sm" color="gray.400">
                    -
                  </Text>
                )}
              </Td>

              <Td textAlign="center">
                <Badge colorScheme={getBadgeColorScheme(detay.gunDurumu)}>
                  {getGunDurumuText(detay.gunDurumu)}
                </Badge>
                {detay.izinTuru && (
                  <Text fontSize="xs" color="gray.500" mt={1}>
                    {detay.izinTuru}
                  </Text>
                )}
              </Td>

              <Td>
                {detay.notlar && (
                  <Tooltip label={detay.notlar}>
                    <Text fontSize="xs" noOfLines={1} maxW="150px">
                      {detay.notlar}
                    </Text>
                  </Tooltip>
                )}
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>

      {detaylar.length === 0 && (
        <Box p={8} textAlign="center">
          <Text color="gray.500">Günlük detay bulunamadı</Text>
        </Box>
      )}
    </Box>
  );
};

export default GunlukDetayTablosu;
