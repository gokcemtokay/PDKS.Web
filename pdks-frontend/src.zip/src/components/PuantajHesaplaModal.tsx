import React, { useState } from 'react';
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Button,
  FormControl,
  FormLabel,
  Select,
  Checkbox,
  useToast,
  VStack,
  HStack,
  Text,
} from '@chakra-ui/react';
import puantajService from '../services/puantajService';
import { getAyListesi, getYilListesi, getTurkceAyAdi } from '../utils/puantajUtils';

interface PuantajHesaplaModalProps {
  isOpen: boolean;
  onClose: () => void;
  personelId?: number;
  onSuccess?: () => void;
}

const PuantajHesaplaModal: React.FC<PuantajHesaplaModalProps> = ({
  isOpen,
  onClose,
  personelId,
  onSuccess,
}) => {
  const [yil, setYil] = useState<number>(new Date().getFullYear());
  const [ay, setAy] = useState<number>(new Date().getMonth() + 1);
  const [yenidenHesapla, setYenidenHesapla] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  
  const toast = useToast();
  const ayListesi = getAyListesi();
  const yilListesi = getYilListesi();

  const handleHesapla = async () => {
    if (!personelId) {
      toast({
        title: 'Hata',
        description: 'Personel seçilmedi',
        status: 'error',
        duration: 3000,
      });
      return;
    }

    setLoading(true);
    try {
      await puantajService.hesaplaPuantaj({
        personelId,
        yil,
        ay,
        yenidenHesapla,
      });

      toast({
        title: 'Başarılı',
        description: `${getTurkceAyAdi(ay)} ${yil} puantajı hesaplandı`,
        status: 'success',
        duration: 3000,
      });

      onClose();
      onSuccess?.();
    } catch (error: any) {
      toast({
        title: 'Hata',
        description: error.response?.data?.message || 'Puantaj hesaplanamadı',
        status: 'error',
        duration: 5000,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="md">
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Puantaj Hesapla</ModalHeader>
        <ModalCloseButton />
        
        <ModalBody>
          <VStack spacing={4} align="stretch">
            <FormControl>
              <FormLabel>Yıl</FormLabel>
              <Select value={yil} onChange={(e) => setYil(Number(e.target.value))}>
                {yilListesi.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </Select>
            </FormControl>

            <FormControl>
              <FormLabel>Ay</FormLabel>
              <Select value={ay} onChange={(e) => setAy(Number(e.target.value))}>
                {ayListesi.map((a) => (
                  <option key={a.value} value={a.value}>
                    {a.label}
                  </option>
                ))}
              </Select>
            </FormControl>

            <FormControl>
              <Checkbox
                isChecked={yenidenHesapla}
                onChange={(e) => setYenidenHesapla(e.target.checked)}
              >
                Mevcut puantajı yeniden hesapla
              </Checkbox>
              <Text fontSize="sm" color="gray.500" mt={1}>
                Bu seçenek mevcut puantajı siler ve yeniden oluşturur
              </Text>
            </FormControl>
          </VStack>
        </ModalBody>

        <ModalFooter>
          <HStack spacing={3}>
            <Button variant="ghost" onClick={onClose}>
              İptal
            </Button>
            <Button
              colorScheme="blue"
              onClick={handleHesapla}
              isLoading={loading}
            >
              Hesapla
            </Button>
          </HStack>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default PuantajHesaplaModal;
