import React, { useState, useEffect } from 'react';
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Button,
  FormControl,
  FormLabel,
  Select,
  Radio,
  RadioGroup,
  Stack,
  useToast,
  VStack,
  HStack,
  Progress,
  Text,
} from '@chakra-ui/react';
import puantajService from '../../services/puantajService';
import { getAyListesi, getYilListesi, getTurkceAyAdi } from '../../utils/puantajUtils';

interface TopluPuantajHesaplaModalProps {
  isOpen: boolean;
  onClose: () => void;
  departmanlar?: { id: number; ad: string }[];
  onSuccess?: () => void;
}

const TopluPuantajHesaplaModal: React.FC<TopluPuantajHesaplaModalProps> = ({
  isOpen,
  onClose,
  departmanlar = [],
  onSuccess,
}) => {
  const [yil, setYil] = useState<number>(new Date().getFullYear());
  const [ay, setAy] = useState<number>(new Date().getMonth() + 1);
  const [secim, setSecim] = useState<string>('tumu');
  const [departmanId, setDepartmanId] = useState<number | undefined>();
  const [loading, setLoading] = useState<boolean>(false);
  
  const toast = useToast();
  const ayListesi = getAyListesi();
  const yilListesi = getYilListesi();

  const handleHesapla = async () => {
    setLoading(true);
    try {
      const data: any = {
        yil,
        ay,
        tumPersonel: secim === 'tumu',
      };

      if (secim === 'departman' && departmanId) {
        data.departmanId = departmanId;
      }

      const result = await puantajService.topluPuantajHesapla(data);

      toast({
        title: 'Başarılı',
        description: result.message,
        status: 'success',
        duration: 5000,
      });

      onClose();
      onSuccess?.();
    } catch (error: any) {
      toast({
        title: 'Hata',
        description: error.response?.data?.message || 'Toplu puantaj hesaplanamadı',
        status: 'error',
        duration: 5000,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="md">
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Toplu Puantaj Hesapla</ModalHeader>
        <ModalCloseButton />
        
        <ModalBody>
          <VStack spacing={4} align="stretch">
            <FormControl>
              <FormLabel>Yıl</FormLabel>
              <Select value={yil} onChange={(e) => setYil(Number(e.target.value))}>
                {yilListesi.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </Select>
            </FormControl>

            <FormControl>
              <FormLabel>Ay</FormLabel>
              <Select value={ay} onChange={(e) => setAy(Number(e.target.value))}>
                {ayListesi.map((a) => (
                  <option key={a.value} value={a.value}>
                    {a.label}
                  </option>
                ))}
              </Select>
            </FormControl>

            <FormControl>
              <FormLabel>Hesaplama Kapsamı</FormLabel>
              <RadioGroup value={secim} onChange={setSecim}>
                <Stack>
                  <Radio value="tumu">Tüm Personel</Radio>
                  <Radio value="departman">Departman Bazlı</Radio>
                </Stack>
              </RadioGroup>
            </FormControl>

            {secim === 'departman' && (
              <FormControl>
                <FormLabel>Departman</FormLabel>
                <Select
                  placeholder="Departman seçin"
                  value={departmanId}
                  onChange={(e) => setDepartmanId(Number(e.target.value))}
                >
                  {departmanlar.map((dept) => (
                    <option key={dept.id} value={dept.id}>
                      {dept.ad}
                    </option>
                  ))}
                </Select>
              </FormControl>
            )}

            {loading && (
              <VStack spacing={2} align="stretch">
                <Progress size="sm" isIndeterminate colorScheme="blue" />
                <Text fontSize="sm" color="gray.600" textAlign="center">
                  Puantajlar hesaplanıyor...
                </Text>
              </VStack>
            )}
          </VStack>
        </ModalBody>

        <ModalFooter>
          <HStack spacing={3}>
            <Button variant="ghost" onClick={onClose} isDisabled={loading}>
              İptal
            </Button>
            <Button
              colorScheme="blue"
              onClick={handleHesapla}
              isLoading={loading}
              isDisabled={secim === 'departman' && !departmanId}
            >
              Toplu Hesapla
            </Button>
          </HStack>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default TopluPuantajHesaplaModal;
