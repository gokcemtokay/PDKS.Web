import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Heading,
  HStack,
  VStack,
  Button,
  Badge,
  useToast,
  Spinner,
  Text,
  Card,
  CardBody,
  CardHeader,
  Flex,
  Grid,
  GridItem,
  Divider,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  IconButton,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
} from '@chakra-ui/react';
import { FiArrowLeft, FiCheck, FiX, FiDownload } from 'react-icons/fi';
import { useParams, useNavigate } from 'react-router-dom';
import puantajService from '../../services/puantajService';
import { PuantajDetail } from '../../types/puantaj.types';
import {
  formatDakika,
  getDurumBadgeClass,
  getDonemText,
} from '../../utils/puantajUtils';
import GunlukDetayTablosu from '../../components/GunlukDetayTablosu';

const PuantajDetay: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const toast = useToast();

  const [puantaj, setPuantaj] = useState<PuantajDetail | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    if (id) {
      loadPuantaj(Number(id));
    }
  }, [id]);

  const loadPuantaj = async (puantajId: number) => {
    setLoading(true);
    try {
      const data = await puantajService.getById(puantajId);
      setPuantaj(data);
    } catch (error: any) {
      toast({
        title: 'Hata',
        description: 'Puantaj detayı yüklenemedi',
        status: 'error',
        duration: 3000,
      });
      navigate('/puantaj');
    } finally {
      setLoading(false);
    }
  };

  const handleOnayla = async () => {
    if (!puantaj) return;

    try {
      // Onaylayan kullanıcı ID'si context'ten alınmalı
      const onaylayanKullaniciId = 1; // TODO: Actual user ID
      
      await puantajService.onayla({
        puantajId: puantaj.id,
        onaylayanKullaniciId,
      });

      toast({
        title: 'Başarılı',
        description: 'Puantaj onaylandı',
        status: 'success',
        duration: 3000,
      });

      loadPuantaj(puantaj.id);
    } catch (error: any) {
      toast({
        title: 'Hata',
        description: error.response?.data?.message || 'Onaylama başarısız',
        status: 'error',
        duration: 3000,
      });
    }
  };

  const handleOnayIptal = async () => {
    if (!puantaj) return;

    try {
      await puantajService.onayIptal(puantaj.id);

      toast({
        title: 'Başarılı',
        description: 'Puantaj onayı iptal edildi',
        status: 'success',
        duration: 3000,
      });

      loadPuantaj(puantaj.id);
    } catch (error: any) {
      toast({
        title: 'Hata',
        description: error.response?.data?.message || 'İptal başarısız',
        status: 'error',
        duration: 3000,
      });
    }
  };

  const getBadgeColorScheme = (durum: string): string => {
    const classMap: { [key: string]: string } = {
      success: 'green',
      warning: 'yellow',
      secondary: 'gray',
      primary: 'blue',
    };
    return classMap[getDurumBadgeClass(durum)] || 'gray';
  };

  if (loading) {
    return (
      <Container maxW="container.xl" py={8}>
        <Flex justify="center" align="center" h="400px">
          <Spinner size="xl" />
        </Flex>
      </Container>
    );
  }

  if (!puantaj) {
    return null;
  }

  return (
    <Container maxW="container.xl" py={8}>
      <VStack spacing={6} align="stretch">
        {/* Header */}
        <Flex justify="space-between" align="center">
          <HStack>
            <IconButton
              aria-label="Geri"
              icon={<FiArrowLeft />}
              onClick={() => navigate('/puantaj')}
            />
            <VStack align="start" spacing={0}>
              <Heading size="lg">{puantaj.personelAdi}</Heading>
              <Text color="gray.600">
                {getDonemText(puantaj.yil, puantaj.ay)} Puantajı
              </Text>
            </VStack>
          </HStack>
          
          <HStack>
            {puantaj.durum === 'Taslak' && (
              <Button
                leftIcon={<FiCheck />}
                colorScheme="green"
                onClick={handleOnayla}
              >
                Onayla
              </Button>
            )}
            {puantaj.durum === 'Onaylandı' && (
              <Button
                leftIcon={<FiX />}
                colorScheme="orange"
                onClick={handleOnayIptal}
              >
                Onayı İptal Et
              </Button>
            )}
            <Button leftIcon={<FiDownload />} variant="outline">
              Excel İndir
            </Button>
          </HStack>
        </Flex>

        {/* Personel Bilgileri */}
        <Card>
          <CardBody>
            <Grid templateColumns="repeat(4, 1fr)" gap={6}>
              <GridItem>
                <Text fontSize="sm" color="gray.600">
                  Sicil No
                </Text>
                <Text fontWeight="medium">{puantaj.sicilNo}</Text>
              </GridItem>
              <GridItem>
                <Text fontSize="sm" color="gray.600">
                  Departman
                </Text>
                <Text fontWeight="medium">{puantaj.departman}</Text>
              </GridItem>
              <GridItem>
                <Text fontSize="sm" color="gray.600">
                  Unvan
                </Text>
                <Text fontWeight="medium">{puantaj.unvan}</Text>
              </GridItem>
              <GridItem>
                <Text fontSize="sm" color="gray.600">
                  Durum
                </Text>
                <Badge colorScheme={getBadgeColorScheme(puantaj.durum)}>
                  {puantaj.durum}
                </Badge>
              </GridItem>
            </Grid>
          </CardBody>
        </Card>

        {/* İstatistikler */}
        <Grid templateColumns="repeat(4, 1fr)" gap={4}>
          <Card>
            <CardBody>
              <Stat>
                <StatLabel>Toplam Çalışma</StatLabel>
                <StatNumber>{formatDakika(puantaj.toplamCalismaSaati)}</StatNumber>
                <StatHelpText>{puantaj.toplamCalisilanGun} gün</StatHelpText>
              </Stat>
            </CardBody>
          </Card>

          <Card>
            <CardBody>
              <Stat>
                <StatLabel>Normal Mesai</StatLabel>
                <StatNumber>{formatDakika(puantaj.normalMesaiSaati)}</StatNumber>
              </Stat>
            </CardBody>
          </Card>

          <Card>
            <CardBody>
              <Stat>
                <StatLabel>Fazla Mesai</StatLabel>
                <StatNumber color="green.600">
                  {formatDakika(puantaj.fazlaMesaiSaati)}
                </StatNumber>
                <StatHelpText>
                  Gece: {formatDakika(puantaj.geceMesaiSaati)}
                </StatHelpText>
              </Stat>
            </CardBody>
          </Card>

          <Card>
            <CardBody>
              <Stat>
                <StatLabel>Hafta Sonu</StatLabel>
                <StatNumber color="purple.600">
                  {formatDakika(puantaj.haftaSonuMesaiSaati)}
                </StatNumber>
              </Stat>
            </CardBody>
          </Card>
        </Grid>

        {/* Devamsızlık & İzin */}
        <Grid templateColumns="repeat(5, 1fr)" gap={4}>
          <Card>
            <CardBody>
              <Stat>
                <StatLabel>Devamsızlık</StatLabel>
                <StatNumber color="red.600">
                  {puantaj.devamsizlikGunu} gün
                </StatNumber>
              </Stat>
            </CardBody>
          </Card>

          <Card>
            <CardBody>
              <Stat>
                <StatLabel>İzin</StatLabel>
                <StatNumber color="blue.600">
                  {puantaj.izinGunu} gün
                </StatNumber>
              </Stat>
            </CardBody>
          </Card>

          <Card>
            <CardBody>
              <Stat>
                <StatLabel>Raporlu</StatLabel>
                <StatNumber>{puantaj.raporluGun} gün</StatNumber>
              </Stat>
            </CardBody>
          </Card>

          <Card>
            <CardBody>
              <Stat>
                <StatLabel>Geç Kalma</StatLabel>
                <StatNumber color="orange.600">
                  {puantaj.gecKalmaGunu} gün
                </StatNumber>
                <StatHelpText>
                  {formatDakika(puantaj.gecKalmaSuresi)}
                </StatHelpText>
              </Stat>
            </CardBody>
          </Card>

          <Card>
            <CardBody>
              <Stat>
                <StatLabel>Erken Çıkış</StatLabel>
                <StatNumber color="orange.600">
                  {puantaj.erkenCikisGunu} gün
                </StatNumber>
                <StatHelpText>
                  {formatDakika(puantaj.erkenCikisSuresi)}
                </StatHelpText>
              </Stat>
            </CardBody>
          </Card>
        </Grid>

        {/* Günlük Detaylar */}
        <Card>
          <CardHeader>
            <Heading size="md">Günlük Detaylar</Heading>
          </CardHeader>
          <CardBody>
            <Tabs>
              <TabList>
                <Tab>Tümü ({puantaj.gunlukDetaylar.length})</Tab>
                <Tab>Normal Günler</Tab>
                <Tab>Özel Durumlar</Tab>
              </TabList>

              <TabPanels>
                <TabPanel px={0}>
                  <GunlukDetayTablosu detaylar={puantaj.gunlukDetaylar} />
                </TabPanel>

                <TabPanel px={0}>
                  <GunlukDetayTablosu
                    detaylar={puantaj.gunlukDetaylar.filter(
                      (d) => d.gunDurumu === 'Normal'
                    )}
                  />
                </TabPanel>

                <TabPanel px={0}>
                  <GunlukDetayTablosu
                    detaylar={puantaj.gunlukDetaylar.filter(
                      (d) => d.gunDurumu !== 'Normal'
                    )}
                  />
                </TabPanel>
              </TabPanels>
            </Tabs>
          </CardBody>
        </Card>

        {/* Onay Bilgileri */}
        {puantaj.onayTarihi && (
          <Card bg="green.50">
            <CardBody>
              <HStack>
                <FiCheck size={24} color="green" />
                <VStack align="start" spacing={0}>
                  <Text fontWeight="medium" color="green.800">
                    Puantaj Onaylandı
                  </Text>
                  <Text fontSize="sm" color="green.700">
                    {puantaj.onaylayanKisi} tarafından{' '}
                    {new Date(puantaj.onayTarihi).toLocaleDateString('tr-TR')} tarihinde onaylandı
                  </Text>
                </VStack>
              </HStack>
            </CardBody>
          </Card>
        )}

        {/* Notlar */}
        {puantaj.notlar && (
          <Card>
            <CardHeader>
              <Heading size="sm">Notlar</Heading>
            </CardHeader>
            <CardBody>
              <Text>{puantaj.notlar}</Text>
            </CardBody>
          </Card>
        )}
      </VStack>
    </Container>
  );
};

export default PuantajDetay;
