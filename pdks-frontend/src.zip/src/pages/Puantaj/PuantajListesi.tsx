import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Heading,
  HStack,
  VStack,
  Button,
  Select,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Badge,
  IconButton,
  useDisclosure,
  useToast,
  Spinner,
  Text,
  Card,
  CardBody,
  Flex,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
} from '@chakra-ui/react';
import { FiEye, FiRefreshCw, FiDownload, FiMoreVertical, FiPlus } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';
import puantajService from '../../services/puantajService';
import { PuantajList } from '../../types/puantaj.types';
import {
  formatDakika,
  getDurumBadgeClass,
  getAyListesi,
  getYilListesi,
  getTurkceAyAdi,
} from '../../utils/puantajUtils';
import TopluPuantajHesaplaModal from '../../components/TopluPuantajHesaplaModal';

const PuantajListesi: React.FC = () => {
  const navigate = useNavigate();
  const toast = useToast();
  const { isOpen, onOpen, onClose } = useDisclosure();

  const [puantajlar, setPuantajlar] = useState<PuantajList[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [yil, setYil] = useState<number>(new Date().getFullYear());
  const [ay, setAy] = useState<number>(new Date().getMonth() + 1);
  const [departmanId, setDepartmanId] = useState<number | undefined>();

  const ayListesi = getAyListesi();
  const yilListesi = getYilListesi();

  useEffect(() => {
    loadPuantajlar();
  }, [yil, ay, departmanId]);

  const loadPuantajlar = async () => {
    setLoading(true);
    try {
      const data = await puantajService.getByDonem(yil, ay, departmanId);
      setPuantajlar(data);
    } catch (error: any) {
      toast({
        title: 'Hata',
        description: 'Puantajlar yüklenemedi',
        status: 'error',
        duration: 3000,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDetayGor = (id: number) => {
    navigate(`/puantaj/${id}`);
  };

  const handleYenidenHesapla = async (id: number) => {
    try {
      await puantajService.yenidenHesapla(id);
      toast({
        title: 'Başarılı',
        description: 'Puantaj yeniden hesaplandı',
        status: 'success',
        duration: 3000,
      });
      loadPuantajlar();
    } catch (error: any) {
      toast({
        title: 'Hata',
        description: error.response?.data?.message || 'Yeniden hesaplanamadı',
        status: 'error',
        duration: 3000,
      });
    }
  };

  const getBadgeColorScheme = (durum: string): string => {
    const classMap: { [key: string]: string } = {
      success: 'green',
      warning: 'yellow',
      secondary: 'gray',
      primary: 'blue',
    };
    return classMap[getDurumBadgeClass(durum)] || 'gray';
  };

  const getStatistics = () => {
    const toplamPersonel = puantajlar.length;
    const toplamCalismaSaati = puantajlar.reduce((sum, p) => sum + p.toplamCalismaSaati, 0);
    const toplamFazlaMesai = puantajlar.reduce((sum, p) => sum + p.fazlaMesaiSaati, 0);
    const toplamDevamsizlik = puantajlar.reduce((sum, p) => sum + p.devamsizlikGunu, 0);
    const onayBekleyen = puantajlar.filter(p => p.durum === 'Taslak').length;

    return {
      toplamPersonel,
      toplamCalismaSaati,
      toplamFazlaMesai,
      toplamDevamsizlik,
      onayBekleyen,
    };
  };

  const stats = getStatistics();

  return (
    <Container maxW="container.xl" py={8}>
      <VStack spacing={6} align="stretch">
        {/* Header */}
        <Flex justify="space-between" align="center">
          <Heading size="lg">Puantaj Yönetimi</Heading>
          <HStack>
            <Button
              leftIcon={<FiPlus />}
              colorScheme="blue"
              onClick={onOpen}
            >
              Toplu Hesapla
            </Button>
          </HStack>
        </Flex>

        {/* Filters */}
        <Card>
          <CardBody>
            <HStack spacing={4}>
              <Box>
                <Text fontSize="sm" mb={1} fontWeight="medium">
                  Yıl
                </Text>
                <Select
                  value={yil}
                  onChange={(e) => setYil(Number(e.target.value))}
                  w="120px"
                >
                  {yilListesi.map((y) => (
                    <option key={y} value={y}>
                      {y}
                    </option>
                  ))}
                </Select>
              </Box>

              <Box>
                <Text fontSize="sm" mb={1} fontWeight="medium">
                  Ay
                </Text>
                <Select
                  value={ay}
                  onChange={(e) => setAy(Number(e.target.value))}
                  w="150px"
                >
                  {ayListesi.map((a) => (
                    <option key={a.value} value={a.value}>
                      {a.label}
                    </option>
                  ))}
                </Select>
              </Box>

              <Box flex={1}>
                <Text fontSize="sm" mb={1} fontWeight="medium">
                  Departman
                </Text>
                <Select
                  placeholder="Tüm Departmanlar"
                  value={departmanId}
                  onChange={(e) =>
                    setDepartmanId(e.target.value ? Number(e.target.value) : undefined)
                  }
                >
                  {/* Departmanlar buraya eklenecek */}
                </Select>
              </Box>

              <Box alignSelf="flex-end">
                <IconButton
                  aria-label="Yenile"
                  icon={<FiRefreshCw />}
                  onClick={loadPuantajlar}
                  isLoading={loading}
                />
              </Box>
            </HStack>
          </CardBody>
        </Card>

        {/* Statistics */}
        <HStack spacing={4}>
          <Card flex={1}>
            <CardBody>
              <Text fontSize="sm" color="gray.600">
                Toplam Personel
              </Text>
              <Heading size="lg" color="blue.600">
                {stats.toplamPersonel}
              </Heading>
            </CardBody>
          </Card>

          <Card flex={1}>
            <CardBody>
              <Text fontSize="sm" color="gray.600">
                Toplam Çalışma
              </Text>
              <Heading size="lg" color="green.600">
                {formatDakika(stats.toplamCalismaSaati)}
              </Heading>
            </CardBody>
          </Card>

          <Card flex={1}>
            <CardBody>
              <Text fontSize="sm" color="gray.600">
                Fazla Mesai
              </Text>
              <Heading size="lg" color="purple.600">
                {formatDakika(stats.toplamFazlaMesai)}
              </Heading>
            </CardBody>
          </Card>

          <Card flex={1}>
            <CardBody>
              <Text fontSize="sm" color="gray.600">
                Onay Bekleyen
              </Text>
              <Heading size="lg" color="orange.600">
                {stats.onayBekleyen}
              </Heading>
            </CardBody>
          </Card>
        </HStack>

        {/* Table */}
        <Card>
          <CardBody>
            {loading ? (
              <Flex justify="center" align="center" h="200px">
                <Spinner size="xl" />
              </Flex>
            ) : (
              <Box overflowX="auto">
                <Table variant="simple">
                  <Thead>
                    <Tr>
                      <Th>Sicil No</Th>
                      <Th>Personel</Th>
                      <Th>Departman</Th>
                      <Th textAlign="center">Çalışma Saati</Th>
                      <Th textAlign="center">Çalışma Günü</Th>
                      <Th textAlign="center">Fazla Mesai</Th>
                      <Th textAlign="center">Devamsızlık</Th>
                      <Th textAlign="center">Durum</Th>
                      <Th textAlign="center">İşlemler</Th>
                    </Tr>
                  </Thead>
                  <Tbody>
                    {puantajlar.map((puantaj) => (
                      <Tr key={puantaj.id}>
                        <Td fontWeight="medium">{puantaj.sicilNo}</Td>
                        <Td>{puantaj.personelAdi}</Td>
                        <Td>{puantaj.departman}</Td>
                        <Td textAlign="center">
                          {formatDakika(puantaj.toplamCalismaSaati)}
                        </Td>
                        <Td textAlign="center">{puantaj.toplamCalisilanGun} gün</Td>
                        <Td textAlign="center">
                          {puantaj.fazlaMesaiSaati > 0 ? (
                            <Text color="green.600" fontWeight="medium">
                              {formatDakika(puantaj.fazlaMesaiSaati)}
                            </Text>
                          ) : (
                            '-'
                          )}
                        </Td>
                        <Td textAlign="center">
                          {puantaj.devamsizlikGunu > 0 ? (
                            <Text color="red.600" fontWeight="medium">
                              {puantaj.devamsizlikGunu} gün
                            </Text>
                          ) : (
                            '-'
                          )}
                        </Td>
                        <Td textAlign="center">
                          <Badge colorScheme={getBadgeColorScheme(puantaj.durum)}>
                            {puantaj.durum}
                          </Badge>
                        </Td>
                        <Td textAlign="center">
                          <HStack spacing={2} justify="center">
                            <IconButton
                              aria-label="Detay"
                              icon={<FiEye />}
                              size="sm"
                              onClick={() => handleDetayGor(puantaj.id)}
                            />
                            <Menu>
                              <MenuButton
                                as={IconButton}
                                aria-label="İşlemler"
                                icon={<FiMoreVertical />}
                                size="sm"
                                variant="ghost"
                              />
                              <MenuList>
                                <MenuItem
                                  icon={<FiRefreshCw />}
                                  onClick={() => handleYenidenHesapla(puantaj.id)}
                                >
                                  Yeniden Hesapla
                                </MenuItem>
                                <MenuItem icon={<FiDownload />}>
                                  Excel İndir
                                </MenuItem>
                              </MenuList>
                            </Menu>
                          </HStack>
                        </Td>
                      </Tr>
                    ))}
                  </Tbody>
                </Table>

                {puantajlar.length === 0 && (
                  <Box p={8} textAlign="center">
                    <Text color="gray.500">
                      {getTurkceAyAdi(ay)} {yil} için puantaj bulunamadı
                    </Text>
                  </Box>
                )}
              </Box>
            )}
          </CardBody>
        </Card>
      </VStack>

      <TopluPuantajHesaplaModal
        isOpen={isOpen}
        onClose={onClose}
        onSuccess={loadPuantajlar}
      />
    </Container>
  );
};

export default PuantajListesi;
