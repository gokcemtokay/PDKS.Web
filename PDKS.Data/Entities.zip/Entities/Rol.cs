using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PDKS.Data.Entities
{
    [Table("Roller")]
    public class Rol
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string RolAdi { get; set; }

        [StringLength(500)]
        public string? Aciklama { get; set; }

        public bool Aktif { get; set; } = true;

        // Navigation Properties
        public ICollection<Kullanici> Kullanicilar { get; set; } = new List<Kullanici>();
        public ICollection<MenuRol> MenuRoller { get; set; } = new List<MenuRol>();
        public ICollection<RolIslemYetki> RolIslemYetkiler { get; set; } = new List<RolIslemYetki>();
    }
}
