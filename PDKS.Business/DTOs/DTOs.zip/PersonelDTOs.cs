﻿namespace PDKS.Business.DTOs
{
    public class PersonelDTOs
    {
    }
}
