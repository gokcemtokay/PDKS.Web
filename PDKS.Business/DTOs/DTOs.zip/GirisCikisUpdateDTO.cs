﻿namespace PDKS.Business.DTOs
{
    public class GirisCikisUpdateDTO : GirisCikisCreateDTO
    {
        public int Id { get; set; }
    }
}
