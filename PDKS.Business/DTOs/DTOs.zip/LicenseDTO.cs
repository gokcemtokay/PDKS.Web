﻿namespace PDKS.Business.DTOs
{
    public class LicenseDTO
    {
        
        public int SirketId { get; set; }
public string LicenseKey { get; set; }
    }
}