﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDKS.Business.DTOs
{
    public class EkipOzetiDTO
    {
        
        public int SirketId { get; set; }
public int ToplamKisi { get; set; }
        public int BugunkuGiris { get; set; }
        public int IzindeKisi { get; set; }
        public int RaporluKisi { get; set; }
        public double OrtalamaPerformans { get; set; }
    }
}
