﻿// PDKS.Business/DTOs/DepartmanListDTO.cs
namespace PDKS.Business.DTOs
{
    public class DepartmanListDTO
    {
        public int Id { get; set; }
        public int SirketId { get; set; }
        public string SirketAdi { get; set; }
        public string DepartmanAdi { get; set; }
        public string Kod { get; set; }
        public string Aciklama { get; set; }
        public int? UstDepartmanId { get; set; }
        public string UstDepartmanAdi { get; set; }
        public int PersonelSayisi { get; set; }
        public bool Durum { get; set; }
    }
}