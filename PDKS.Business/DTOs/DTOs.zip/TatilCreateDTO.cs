﻿using System.ComponentModel.DataAnnotations;

namespace PDKS.Business.DTOs
{
    public class TatilCreateDTO
    {
        [Required(ErrorMessage = "Tatil adı zorunludur")]
        [StringLength(100)]
        
        public int SirketId { get; set; }
public string Ad { get; set; }

        [Required(ErrorMessage = "Tarih zorunludur")]
        public DateTime Tarih { get; set; }

        [StringLength(500)]
        public string? Aciklama { get; set; }
    }
}