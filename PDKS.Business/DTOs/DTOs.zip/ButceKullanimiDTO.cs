﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDKS.Business.DTOs
{
    public class ButceKullanimiDTO
    {
        
        public int SirketId { get; set; }
public decimal ToplamButce { get; set; }
        public decimal KullanilanButce { get; set; }
        public decimal KalanButce { get; set; }
        public double KullanimYuzdesi { get; set; }
    }
}
